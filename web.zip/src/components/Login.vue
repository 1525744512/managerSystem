<template>
  <div class="login">
    <div class="card">
      <card>
        <Form ref="formItem" :model="formItem" :rules="ruleValidate" :label-width="0" class="loginForm">
          <FormItem prop="username" class="userName">
            <Input size="large" placeholder="请输入账号" v-model="formItem.username"  >
              <Icon type="ios-contact" slot="prefix" />
            </Input>
          </FormItem>
          <FormItem prop="password" class="passWord">
            <Input size="large"  placeholder="请输入密码" v-model="formItem.password" type="password">
              <Icon type="ios-lock"  slot="prefix"/>
            </Input>
          </FormItem>
        </Form>
        <div class="flexBetween">
          <Checkbox size="large"  v-model="single" style="height: 100%">自动登录</Checkbox>
          <A type="text" @click="handleSubmit('formItem')" style="float: right;height: 100%;color: cornflowerblue" >忘记密码?</A>
        </div>
        <Button type="primary" size="large"  @click="handleSubmit('formItem')" class="loginButton">登录</Button>
      </card>
    </div>
  </div>
</template>

<script>
export default {
  name: "Login",
  data() {
    return {
      // 表单
      formItem: {
        username: "",
        password: "",
      },
      // 校验规则
      ruleValidate: {
        username: [{
          required: true,
          message: "输入用户名",
          trigger: "blur",
        }, ],
        password: [{
          required: true,
          message: "输入密码",
          trigger: "blur",
        }, ],
      },
    };
  },
  methods: {
    // 提交表单
    handleSubmit(name) {
      var that = this;

      // 校验表单数据
      that.$refs[name].validate((valid) => {
        if (valid) {
          // 校验成功 发起请求
          that.axios({
                method: "post",
                url: that.apis.pc.login.login,
                data: that.formItem,
              })
              .then((res) => {
                let code = res.data.code;
                let msg = res.data.msg;
                let data = res.data.data;
                if (code === 200) {
                  that.$Message.success("Success!");

                  //保存到vuex中，方便其他组件调用
                  that.setUserInfo(data);

                  //保存一份到缓存中，以便页面刷新时获取用户数据
                  that.utils.storeTool.localstorageSet("userInfo", data);

                  //如果登录成功进行转
                  that.$router.push("/welcome/index");
                } else {
                  // todo 登录失败处理
                  that.$Message.error(msg);
                }
              })
              .catch(function() {
                //todo 接口访问异常处理
                that.$Message.error("Fail!");
              });
        } else {
          that.$Message.error("Fail!");
        }
      });

    },

    // 重置表单
    handleReset(name) {
      this.$refs[name].resetFields();
    },
  },
};
</script>

<style scoped>
.loginButton {
  width: 100%;
  margin-top: 5%;
}
.login {
  display: flex;
  justify-content: center;
  align-items: center;
  background: url("../assets/background.jpg") no-repeat;
  background-size: cover;
  min-width: 100%;
  min-height: 100%;
  position: absolute;
}
.flexBetween{
  width: 100%;
  height: 100%;
}
.loginForm{
  width: 300px;
  height: 100%;
  margin-top: 5%;
}
.userName{

}
</style>